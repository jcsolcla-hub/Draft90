import React, { useState } from 'react';
import { X, LogIn, User as UserIcon, Shield, Sparkles, LogOut } from 'lucide-react';
import { User, signInWithGoogle, signInAnonymously, logoutUser } from '../lib/firebase';
import { sound } from '../utils/audio';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, currentUser }) => {
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGoogleLogin = async () => {
    sound.playClick();
    setLoading(true);
    setErrorMsg(null);
    try {
      await signInWithGoogle();
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Error al iniciar sesión con Google.');
    } finally {
      setLoading(false);
    }
  };

  const handleAnonLogin = async () => {
    sound.playClick();
    setLoading(true);
    setErrorMsg(null);
    try {
      await signInAnonymously();
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Error al iniciar sesión anónima.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    sound.playClick();
    setLoading(true);
    try {
      await logoutUser();
      onClose();
    } catch (err: any) {
      setErrorMsg('Error al cerrar sesión.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#121826] border-2 border-[#2b3b5c] rounded-2xl max-w-md w-full overflow-hidden shadow-2xl relative">
        {/* Header */}
        <div className="bg-[#182234] p-4 border-b border-[#2b3b5c] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#ef4444]" />
            <h3 className="font-display font-black text-lg text-white uppercase tracking-wider">
              {currentUser ? 'Perfil de Usuario' : 'Iniciar Sesión'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 flex flex-col gap-5 text-center">
          {currentUser ? (
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.displayName || 'Usuario'}
                    className="w-20 h-20 rounded-full border-4 border-[#ef4444] shadow-xl object-cover"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-[#182234] border-4 border-[#ef4444] flex items-center justify-center text-white">
                    <UserIcon className="w-10 h-10 text-gray-300" />
                  </div>
                )}
                <span className="absolute bottom-0 right-0 w-5 h-5 bg-emerald-500 border-2 border-[#121826] rounded-full" />
              </div>

              <div>
                <h4 className="font-display font-black text-xl text-white">
                  {currentUser.displayName || (currentUser.isAnonymous ? 'Entrenador Anónimo' : 'Entrenador Draft')}
                </h4>
                <p className="text-xs font-mono text-gray-400 mt-1">
                  {currentUser.email || (currentUser.isAnonymous ? 'Sesión de Invitado' : currentUser.uid)}
                </p>
                <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-[11px] font-mono font-bold">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{currentUser.isAnonymous ? 'MODO INVITADO' : 'CUENTA VERIFICADA GOOGLE'}</span>
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 bg-red-950/80 border border-red-500/50 rounded-xl text-red-300 text-xs font-mono w-full text-left">
                  {errorMsg}
                </div>
              )}

              <button
                onClick={handleLogout}
                disabled={loading}
                className="w-full mt-2 py-3 px-4 rounded-xl bg-red-950/60 hover:bg-red-900/90 text-red-200 hover:text-white font-display font-black text-sm border-2 border-red-700/70 shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 disabled:opacity-50"
              >
                <LogOut className="w-4 h-4 text-red-400" />
                <span>{loading ? 'CERRANDO SESIÓN...' : 'CERRAR SESIÓN'}</span>
              </button>
            </div>
          ) : (
            <>
              <div className="flex flex-col items-center gap-2">
                <div className="w-14 h-14 rounded-2xl bg-[#182234] border-2 border-[#ef4444] flex items-center justify-center text-[#ef4444] shadow-lg">
                  <LogIn className="w-7 h-7" />
                </div>
                <h4 className="font-display font-black text-xl text-white uppercase tracking-tight">
                  ACCEDE A DRAFT 90
                </h4>
                <p className="text-xs font-mono text-gray-400 max-w-xs">
                  Inicia sesión para guardar tu progreso, historial de torneos y estadísticas.
                </p>
              </div>

              {errorMsg && (
                <div className="p-3 bg-red-950/80 border border-red-500/50 rounded-xl text-red-300 text-xs font-mono">
                  {errorMsg}
                </div>
              )}

              <div className="flex flex-col gap-3 mt-2">
                {/* Google Login */}
                <button
                  onClick={handleGoogleLogin}
                  disabled={loading}
                  className="w-full py-3.5 px-4 rounded-xl bg-white hover:bg-gray-100 text-gray-900 font-display font-black text-sm border-2 border-gray-300 shadow-xl transition-all flex items-center justify-center gap-3 cursor-pointer active:scale-95"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>ENTRAR CON GOOGLE</span>
                </button>

                {/* Anonymous Login */}
                <button
                  onClick={handleAnonLogin}
                  disabled={loading}
                  className="w-full py-3.5 px-4 rounded-xl bg-[#182234] hover:bg-[#223049] text-white font-display font-bold text-sm border-2 border-[#2b3b5c] shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <UserIcon className="w-4 h-4 text-amber-400" />
                  <span>ENTRAR COMO ANÓNIMO (INVITADO)</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
